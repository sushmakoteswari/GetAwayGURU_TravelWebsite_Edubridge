package com.TravelWebsite.GetAwayGuru;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetAwayGuruuuApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetAwayGuruuuApplication.class, args);
	}

}
